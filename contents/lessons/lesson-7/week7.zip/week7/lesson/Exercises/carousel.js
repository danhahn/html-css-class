 $(document).ready(function(){
    $('#photo-carousel').tinycarousel();
});