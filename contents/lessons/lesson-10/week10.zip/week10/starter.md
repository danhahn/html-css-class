# Getting started

Make sure you are in week10 in your terminal 

## SSG

1. sudo npm install wintersmith -g
2. wintersmith new blog
3. cd blog
4. wintersmith preview
5. view on http://localhost:8080
6. wintersmith build

## Create React App

1. sudo npm install -g create-react-app
2. create-react-app my-app
3. cd my-app/
4. npm start
5. view on http://localhost:3000/